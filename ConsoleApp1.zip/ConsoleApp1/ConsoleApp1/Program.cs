﻿using System.Diagnostics;

namespace ConsoleApp1
{
    internal class Program
    {
        public delegate void VisualiseCallback(int[] array);
        static void Main(string[] args)
        {

            Console.WriteLine("Sorting Algorithm Visualiser");
            Console.WriteLine("Enter size of array:");
            int size = int.Parse(Console.ReadLine());


            Console.WriteLine("Choose input structure:");
            Console.WriteLine("[1] Sorted\n[2] Reverse Sorted\n[3] Random\n[4] Nearly Sorted");
            int choice = int.Parse(Console.ReadLine());
            int[] array = choice switch
            {
                1 => ArrayGenerator.GenerateSorted(size),           // Already sorted
                2 => ArrayGenerator.GenerateReverseSorted(size),    // Sorted in reverse
                3 => ArrayGenerator.GenerateRandom(size),           // Completely random values
                4 => ArrayGenerator.GenerateNearlySorted(size),     // Mostly sorted, with some swapped values
                _ => throw new Exception("Invalid input structure") // Handle invalid inputs
            };
            Console.WriteLine("Choose sorting algorithm: ");
            Console.WriteLine(" [1] Bubble Sort \n [2] Merge Sort \n [3] Quick Sort");
            int algorithm = int.Parse(Console.ReadLine());
            Stopwatch stopwatch = new Stopwatch();
            Action<int[]> visualiseCallback = null;
            Console.WriteLine("Use Visualisation? (y/n): ");
            bool visualisationEnabled = Console.ReadLine().ToLower() == "y";
            if (visualisationEnabled)
            {
                visualiseCallback = arr =>
                {
                    Visualiser.PrintArray(arr, useBars: false); // or useBars: true
                    Visualiser.Pause(50);
                };
            }
            int swaps = algorithm switch
            {
                1 => Sorter.BubbleSort(array, visualiseCallback),
                2 => Sorter.MergeSort(array, visualiseCallback),
                3 => Sorter.QuickSort(array,0,array.Length - 1, visualiseCallback),
                _ => throw new Exception("Invalid algorithm choice")
            };
            
            Console.WriteLine($"Completed in {stopwatch.ElapsedMilliseconds}ms");
            Console.WriteLine($"Total swaps: {swaps}");
        }
    }


    class ArrayGenerator
    {
        public static int[] GenerateSorted(int size)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
                array[i] = i + 1; 
            return array;
        }

        public static int[] GenerateReverseSorted(int size)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
                array[i] = size - i; 
            return array;
        }
        public static int[] GenerateRandom(int size)
        {
            Random rng = new Random();
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
                array[i] = rng.Next(1, size + 1) ; 
            return array;
        }

        public static int[] GenerateNearlySorted(int size)
        {
            int[] array = GenerateSorted(size); 
            Random rng = new Random();
            for (int i = 0; i < size / 10; i++)
            {
                int index1 = rng.Next(size);
                int index2 = rng.Next(size);

                (array[index1], array[index2]) = (array[index2], array[index1]);
            }
            return array;
        }
    }

    class Sorter
    {
        public static int BubbleSort(int[] array, Action<int[]> visualise = null)
        {
            int swaps = 0;
            int n = array.Length;
            bool swapped;


            for (int i = 0; i < n - 1; i++)
            {
                swapped = false;
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (array[j] > array[j + 1])
                    {
                        (array[j], array[j + 1]) = (array[j + 1], array[j]);
                        swaps++;
                        visualise?.Invoke(array);
                        Visualiser.Pause(50);
                        swapped = true;
                    }
                }
                if (!swapped)
                    break;
            }

            return swaps;
        }

        // Merge Sort
        public static int MergeSort(int[] array, Action<int[]> visualise = null)
        {
            int swaps = 0;
            MergeSortHelper(array, 0, array.Length - 1, visualise);
            return swaps;
        }

        private static void MergeSortHelper(int[] array, int left, int right, Action<int[]> visualise = null)
        {
            if (left < right)
            {
                int mid = (left + right) / 2;

                MergeSortHelper(array, left, mid);
                MergeSortHelper(array, mid + 1, right);
                Merge(array, left, mid, right, visualise);
            }
        }

        private static void Merge(int[] array, int left, int mid, int right, Action<int[]> visualise = null)
        {
            int swaps = 0;
            int[] leftArray = new int[mid - left + 1];
            int[] rightArray = new int[right - mid];

            Array.Copy(array, left, leftArray, 0, leftArray.Length);
            Array.Copy(array, mid + 1, rightArray, 0, rightArray.Length);

            int i = 0, j = 0, k = left;

            while (i < leftArray.Length && j < rightArray.Length)
            {
                if (leftArray[i] <= rightArray[j])
                {
                    array[k++] = leftArray[i++];
                    visualise?.Invoke(array);
                    Visualiser.Pause(50);
                }
                else
                {
                    array[k++] = rightArray[j++];
                    visualise?.Invoke(array);
                    Visualiser.Pause(50);
                    swaps++;
                }
            }


            while (i < leftArray.Length)
            {
                array[k++] = leftArray[i++];
                visualise?.Invoke(array);
                Visualiser.Pause(50);
            }
            while (j < rightArray.Length)
            {
                array[k++] = rightArray[j++];
                visualise?.Invoke(array);
                Visualiser.Pause(50);
            }

        }
        public static int QuickSort(int[] array, int left, int right, Action<int[]>? visualise = null)
        {
            int swaps = 0;
            if (left >= right) return swaps;

            int pivotIndex = Partition(array, left, right,ref swaps, visualise);

            visualise?.Invoke(array);
            Visualiser.Pause(50); 

            QuickSort(array, left, pivotIndex - 1, visualise);
            QuickSort(array, pivotIndex + 1, right, visualise);
            return swaps;
        }

        private static int Partition(int[] array, int low, int high,ref int swaps, Action<int[]>? visualise = null)
        {
            int pivot = array[high];
            int i = low - 1;

            for (int j = low; j < high; j++)
            {
                if (array[j] < pivot)
                {
                    i++;
                    (array[i], array[j]) = (array[j], array[i]);
                    swaps++;
                    visualise?.Invoke(array);
                    Visualiser.Pause(50);
                }
            }

            (array[i + 1], array[high]) = (array[high], array[i + 1]);
            visualise?.Invoke(array);
            Visualiser.Pause(50);
            swaps++;
            return i + 1;
        }
    }
    class Visualiser
    {
        public static void PrintArray(int[] array, bool useBars = true)
        {
            Console.Clear();
            foreach (int item in array)
            {
                Console.Write(item + " ");

            }
        }
        public static void Pause (int delayMilliseconds = 100)
        {
            Thread.Sleep(delayMilliseconds);
        }
    }
}
